# PluralsightTweet

**TODO: Add description**

## Installation

If [available in Hex](https://hex.pm/docs/publish), the package can be installed as:

  1. Add `pluralsight_tweet` to your list of dependencies in `mix.exs`:

    ```elixir
    def deps do
      [{:pluralsight_tweet, "~> 0.1.0"}]
    end
    ```

  2. Ensure `pluralsight_tweet` is started before your application:

    ```elixir
    def application do
      [applications: [:pluralsight_tweet]]
    end
    ```

