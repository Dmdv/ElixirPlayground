defmodule PluralsightTweetTest do
  use ExUnit.Case
  doctest PluralsightTweet

  test "the truth" do
    assert 1 + 1 == 2
  end
end
