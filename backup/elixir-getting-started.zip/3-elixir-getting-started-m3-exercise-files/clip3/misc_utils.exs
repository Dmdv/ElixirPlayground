defmodule ModulePlayground.Misc.Utils.Math do
    def add(a, b) do
        a + b
    end
end