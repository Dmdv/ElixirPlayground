defmodule ModulePlayground do
    
end