defmodule Sample.Utils do
    def square(a), do: a * a
    
    def sum(a,b), do: a + b
end