defmodule Sample.Enum do
    def first(list) do
        hd(first)
    end
end