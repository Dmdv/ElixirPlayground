defmodule Sample.Enum do
    def first(list) do
        hd(list)     
    end
end